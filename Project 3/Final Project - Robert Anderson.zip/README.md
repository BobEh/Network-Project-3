This program works in all configurations but it is recommended that it is run in Release mode on x64.

You can control the player by holding down the 'ctrl' button and using the following keys:

W = move forward
A = move left
S = move back
D = move right
R = revive players
SPACE = shoot bullet
