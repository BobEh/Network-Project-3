#include "cLightImp.h"

void cLightImp::doubleLinearAttenuation()
{
	this->linearAttenuation *= 2;
}