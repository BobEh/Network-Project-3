#pragma once


class cLightImp
{
public:
	void doubleLinearAttenuation();

private:
	float linearAttenuation;
};