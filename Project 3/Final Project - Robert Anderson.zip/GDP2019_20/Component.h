#ifndef Component_h
#define Component_h

class Component {
public:
	virtual ~Component(void) { }

protected:
	Component(void) { }
};

#endif
